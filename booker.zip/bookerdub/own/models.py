from django.db import models
from django.contrib.auth.models import User

class UserProfileInfo(models.Model):
	username = models.CharField(max_length=20, default=None)
	password = models.CharField(max_length=10,default=None)


mo_choices = (('pvp','PVP Cinemas'),('ana','Annapurna cinema hall'),('maru','Maruthi cinema hall'))

class Details(models.Model):
	username = models.CharField(max_length=20, default=None)
	mobilenumber = models.CharField(max_length=20, default=None)
	theatres = models.CharField(max_length=10, choices=mo_choices,default="PVP")
	

