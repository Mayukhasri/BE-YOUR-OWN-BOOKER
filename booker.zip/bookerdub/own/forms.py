from django import forms
from django.contrib.auth.models import User
from own.models import UserProfileInfo
from own.models import Details

class UserForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput())
    class Meta():
        model = UserProfileInfo
        fields = ('username','password')

class Details_form(forms.ModelForm):
   
    class Meta():
        model = Details
        fields = ('username','mobilenumber','theatres')
