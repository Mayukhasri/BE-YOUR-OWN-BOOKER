from django.urls import path
from . import views

urlpatterns = [
	path('', views.index, name='index'),
	path('index', views.index, name='index'),
        path('movies', views.movies, name='movies'),
	path('Airaa', views.Airaa, name='Airaa'),
	path('alladin', views.alladin, name='alladin'),
	path('avatar', views.avatar, name='avatar'),
	path('avengers', views.avengers, name='avengers'),
	path('blank', views.blank, name='blank'),
        path('events', views.events, name='events'),
	path('intruder', views.intruder, name='intruder'),
	path('Jersy', views.jersy, name='Jersy'),
	path('kalank', views.kalank, name='kalank'),
	path('kanchana3', views.kanchana3, name='kanchana3'),
	path('Maharshi', views.Maharshi, name='Maharshi'),
	path('annapurna', views.annapurna, name='annapurna'),
	path('tiger', views.tiger, name='tiger'),
        path('venky', views.venky, name='venky'),
        path('form', views.form, name='form'),
	path('user_login',views.user_login, name='user_login'),
	path('register',views.register, name='register'),
        path('pick',views.pick, name='pick'),
]
