from django.apps import AppConfig


class OwnConfig(AppConfig):
    name = 'own'
