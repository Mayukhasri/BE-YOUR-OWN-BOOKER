from django.contrib import admin
from own.models import UserProfileInfo,Details
# Register your models here.
admin.site.register(UserProfileInfo)
admin.site.register(Details)
