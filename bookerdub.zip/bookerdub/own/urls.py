from django.urls import path
from . import views

urlpatterns = [
	path('', views.index, name='index'),
	path('index', views.index, name='index'),
        path('movies', views.movies, name='movies'),
	path('Airaa', views.Airaa, name='Airaa'),
	path('alladin', views.alladin, name='alladin'),
	path('avatar', views.avatar, name='avatar'),
	path('avengers', views.avengers, name='avengers'),
	path('blank', views.blank, name='blank'),
        path('events', views.events, name='events'),
	path('event_payment', views.event_payment, name='event_payment'),
	path('event_payment1', views.event_payment1, name='event_payment1'),
	path('event_payment2', views.event_payment2, name='event_payment2'),
	path('intruder', views.intruder, name='intruder'),
	path('Jersy', views.jersy, name='Jersy'),
	path('kalank', views.kalank, name='kalank'),
	path('kanchana3', views.kanchana3, name='kanchana3'),
	path('Maharshi', views.Maharshi, name='Maharshi'),
	path('pvp', views.pvp, name='pvp'),
	path('annapurna', views.annapurna, name='annapurna'),
	path('maruthi', views.maruthi, name='maruthi'),
	path('tiger', views.tiger, name='tiger'),
        path('venky', views.venky, name='venky'),
        path('success', views.success, name='success'),
	path('login',views.login, name='login'),
	path('register',views.register, name='register'),
	
]
