from django.shortcuts import render, redirect
from own.forms import UserForm
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponseRedirect, HttpResponse
from django.urls import reverse
from django.contrib.auth.decorators import login_required
from django.contrib.auth.hashers import make_password
from own.models import UserProfileInfo
def index(request):
	return render(request, 'index.html')

def Airaa(request):
	return render(request, 'Airaa.html')

def alladin(request):
	return render(request, 'alladin.html')

def avatar(request):
	return render(request, 'avatar.html')

def avengers(request):
	return render(request, 'avengers.html')

def blank(request):
	return render(request, 'blank.html')

def events(request):
	return render(request, 'events.html')

def event_payment(request):
	return render(request, 'event_payment.html')

def event_payment1(request):
	return render(request, 'event_payment1.html')

def event_payment2(request):
	return render(request, 'event_payment2.html')

def intruder(request):
	return render(request, 'intruder.html')

def jersy(request):
	return render(request, 'Jersy.html')

def kalank(request):
	return render(request, 'kalank.html')

def kanchana3(request):
	return render(request, 'kanchana3.html')

def Maharshi(request):
	return render(request, 'Maharshi.html')

def movies(request):
	return render(request, 'movies.html')

def annapurna(request):
	return render(request, 'annapurna.html')

def tiger(request):
	return render(request, 'tiger.html')

def venky(request):
	return render(request, 'venky.html')

def pvp(request):
	return render(request, 'pvp.html')

def maruthi(request):
	return render(request, 'maruthi.html')

def pick(request):
	return render(request, 'pick.html')

def form(request):
	if request.method == 'POST':
		form = form(request.POST)
		if form.is_valid():
			pass #does nothing just triger the validation
	else:
		form = form()
	return render(request,'index.html',{'form':form})

@login_required
def special(request):
    return HttpResponse("You are logged in !")
@login_required
def logout(request):
    logout(request)
    return HttpResponseRedirect(reverse('index'))
def register(request):
    registered = False
    if request.method == 'POST':
        user_form = UserForm(data=request.POST)
       
        if user_form.is_valid():
	    #user.password=make_password(user.clen_data['password'])
            user = user_form.save()
            user.save()
            registered = True
            #return render(request,'index.html',{'user_form':user_form,'registered':registered})
        else:
            print(user_form.errors)
    else:
        user_form = UserForm()
    return render(request,'register.html',{'user_form':user_form,'registered':registered})
def user_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username, password=password)
        if user:
            if user.is_active:
                login(request,user)
                return render(request, 'form.html')
            else:
                return HttpResponse("Your account was inactive.")
        else:
            print("Someone tried to login and failed.")
            print("They used username: {} and password: {}".format(username,password))
            return HttpResponse("Invalid login details given")
    else:
        return render(request, 'user_login.html')
def form(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username, password=password)
        if user:
            if user.is_active:
                login(request,user)
                return render(request, 'pic.html')
            else:
                return HttpResponse("Your account was inactive.")
        else:
            print("Someone tried to login and failed.")
            print("They used username: {} and password: {}".format(username,password))
            return HttpResponse("Invalid login details given")
    else:
        return render(request, 'form.html')


