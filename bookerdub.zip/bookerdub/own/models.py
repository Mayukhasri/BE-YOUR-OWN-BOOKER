from django.db import models
from django.contrib.auth.models import User

class UserProfileInfo(models.Model):
	username = models.CharField(max_length=20, default=None)
	password = models.CharField(max_length=10,default=None)
def __str__(self):
  return self.UserProfileInfo.username,self.UserProfileInfo.password



